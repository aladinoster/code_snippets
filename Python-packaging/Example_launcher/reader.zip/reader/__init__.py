# Absolute import 
from reader.reader import Reader

# relative import 
from .reader import Reader 